class PromptImage {
  final String id;
  final String imageUrl;
  final String prompt;
  final String? title;
  final String? category;
  final int views;
  final String? aiModel;

  const PromptImage({
    required this.id,
    required this.imageUrl,
    required this.prompt,
    this.title,
    this.category,
    required this.views,
    this.aiModel,
  });

  factory PromptImage.fromMap(Map<String, dynamic> m) => PromptImage(
    id: m['id'].toString(),
    imageUrl: m['image_url'] as String,
    prompt: m['prompt'] as String,
    title: m['title'] as String?,
    category: (m['categories'] as Map?)?['name'] as String?,
    views: (m['views'] as num?)?.toInt() ?? 0,
    aiModel: m['ai_model'] as String?,
  );
}
