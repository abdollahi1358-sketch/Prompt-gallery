import 'package:flutter/material.dart';
import '../models/prompt_image.dart';
import '../services/app_config.dart';
import '../services/gallery_service.dart';
import 'detail_screen.dart';

class HomeScreen extends StatefulWidget {
  final AppConfig config;
  const HomeScreen({super.key, required this.config});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final service = GalleryService();
  final scroll = ScrollController();
  final items = <PromptImage>[];
  final search = TextEditingController();
  bool loading = false;
  int page = 0;
  String? selectedCategory;

  @override
  void initState() {
    super.initState();
    _load();
    scroll.addListener(() {
      if (scroll.position.pixels > scroll.position.maxScrollExtent - 600) _load();
    });
  }

  Future<void> _load() async {
    if (loading) return;
    setState(() => loading = true);
    try {
      final data = await service.fetchImages(
        page: page,
        categoryId: selectedCategory,
        search: search.text,
      );
      if (mounted) setState(() {
        items.addAll(data);
        page++;
      });
    } catch (_) {}
    if (mounted) setState(() => loading = false);
  }

  Future<void> _refresh() async {
    items.clear();
    page = 0;
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: CustomScrollView(
          controller: scroll,
          slivers: [
            SliverToBoxAdapter(child: _header()),
            SliverToBoxAdapter(child: _search()),
            SliverToBoxAdapter(child: _categories()),
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(9, 8, 9, 24),
              sliver: SliverGrid(
                delegate: SliverChildBuilderDelegate((context, i) {
                  if (i >= items.length) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  final item = items[i];
                  return _card(item);
                }, childCount: items.length + (loading ? 2 : 0)),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 9,
                  mainAxisSpacing: 12,
                  childAspectRatio: .68,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _header() => Padding(
    padding: const EdgeInsets.fromLTRB(15, 10, 15, 7),
    child: Row(
      children: [
        Expanded(
          child: Text(widget.config.appName,
            style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
          ),
          child: Text('${widget.config.totalImages} images',
            style: const TextStyle(fontWeight: FontWeight.w800)),
        ),
      ],
    ),
  );

  Widget _search() => Padding(
    padding: const EdgeInsets.fromLTRB(15, 2, 15, 8),
    child: TextField(
      controller: search,
      onSubmitted: (_) => _refresh(),
      decoration: InputDecoration(
        hintText: 'Search prompts...',
        prefixIcon: const Icon(Icons.search),
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(22),
          borderSide: BorderSide.none,
        ),
      ),
    ),
  );

  Widget _categories() => SizedBox(
    height: 52,
    child: FutureBuilder<List<Map<String, dynamic>>>(
      future: service.categories(),
      builder: (context, snap) {
        final cats = snap.data ?? [];
        return ListView.separated(
          padding: const EdgeInsets.symmetric(horizontal: 10),
          scrollDirection: Axis.horizontal,
          itemCount: cats.length + 1,
          separatorBuilder: (_, __) => const SizedBox(width: 7),
          itemBuilder: (_, i) {
            if (i == 0) return _pill('✦', 'All', null);
            final c = cats[i - 1];
            return _pill(c['icon'] ?? '•', c['name'], c['id']);
          },
        );
      },
    ),
  );

  Widget _pill(String icon, String label, String? id) {
    final active = selectedCategory == id;
    return GestureDetector(
      onTap: () async {
        setState(() => selectedCategory = id);
        await _refresh();
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 8),
        decoration: BoxDecoration(
          color: active ? Colors.white : Colors.white.withOpacity(.75),
          borderRadius: BorderRadius.circular(25),
        ),
        child: Row(children: [
          Text(icon, style: const TextStyle(fontSize: 17)),
          const SizedBox(width: 6),
          Text(label, style: const TextStyle(fontWeight: FontWeight.w800)),
        ]),
      ),
    );
  }

  Widget _card(PromptImage item) => GestureDetector(
    onTap: () => Navigator.push(
      context, MaterialPageRoute(builder: (_) => DetailScreen(item: item))),
    child: Container(
      padding: const EdgeInsets.all(7),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(30),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(23),
        child: Stack(fit: StackFit.expand, children: [
          Image.network(item.imageUrl, fit: BoxFit.cover),
          Positioned(
            left: 12, bottom: 11,
            child: Row(children: [
              const Icon(Icons.visibility, color: Colors.white, size: 21),
              const SizedBox(width: 5),
              Text(_views(item.views),
                style: const TextStyle(color: Colors.white, fontSize: 17,
                  fontWeight: FontWeight.w800,
                  shadows: [Shadow(blurRadius: 6, color: Colors.black87)])),
            ]),
          )
        ]),
      ),
    ),
  );

  String _views(int n) => n >= 1000000
      ? '${(n / 1000000).toStringAsFixed(1)}M+'
      : n >= 1000 ? '${(n / 1000).toStringAsFixed(1)}K+' : '$n';

  @override
  void dispose() {
    scroll.dispose();
    search.dispose();
    super.dispose();
  }
}
