import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/prompt_image.dart';
import '../services/gallery_service.dart';

class DetailScreen extends StatefulWidget {
  final PromptImage item;
  const DetailScreen({super.key, required this.item});

  @override
  State<DetailScreen> createState() => _DetailScreenState();
}

class _DetailScreenState extends State<DetailScreen> {
  bool saved = false;
  Map<String, dynamic>? ad;
  final service = GalleryService();

  @override
  void initState() {
    super.initState();
    service.addView(widget.item.id);
    _loadLocalSave();
    _loadAd();
  }

  Future<void> _loadLocalSave() async {
    final p = await SharedPreferences.getInstance();
    setState(() => saved = p.getBool('saved_${widget.item.id}') ?? false);
  }

  Future<void> _toggleSave() async {
    final p = await SharedPreferences.getInstance();
    final next = !saved;
    await p.setBool('saved_${widget.item.id}', next);
    setState(() => saved = next);
  }

  Future<void> _loadAd() async {
    try {
      final ads = await service.ads();
      if (ads.isNotEmpty && mounted) setState(() => ad = ads.first);
    } catch (_) {}
  }

  Future<void> _open(String url) async {
    await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) {
    final item = widget.item;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Prompt'),
        actions: [
          IconButton(
            onPressed: _toggleSave,
            icon: Icon(saved ? Icons.bookmark : Icons.bookmark_border),
          )
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(25),
            child: Image.network(item.imageUrl),
          ),
          const SizedBox(height: 12),
          Text('👁 ${item.views} views',
            style: const TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 16),
          const Text('PROMPT',
            style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.4)),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFFE9ECE4),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(item.prompt, style: const TextStyle(fontSize: 16, height: 1.55)),
          ),
          const SizedBox(height: 10),
          FilledButton.icon(
            onPressed: () async {
              await Clipboard.setData(ClipboardData(text: item.prompt));
              if (mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Prompt copied')),
                );
              }
            },
            icon: const Icon(Icons.copy),
            label: const Text('Copy Prompt'),
          ),
          Row(children: [
            Expanded(child: OutlinedButton.icon(
              onPressed: () => _open('https://chatgpt.com/'),
              icon: const Icon(Icons.auto_awesome), label: const Text('ChatGPT'))),
            const SizedBox(width: 8),
            Expanded(child: OutlinedButton.icon(
              onPressed: () => _open('https://gemini.google.com/'),
              icon: const Icon(Icons.diamond_outlined), label: const Text('Gemini'))),
          ]),
          const SizedBox(height: 15),
          if (ad != null)
            GestureDetector(
              onTap: ad!['target_url'] == null ? null : () => _open(ad!['target_url']),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: Image.network(ad!['image_url'], fit: BoxFit.cover),
              ),
            )
          else
            Container(
              height: 88,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: Colors.grey.shade300,
                borderRadius: BorderRadius.circular(16),
              ),
              child: const Text('ADVERTISEMENT'),
            ),
        ],
      ),
    );
  }
}
