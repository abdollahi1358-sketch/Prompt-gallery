import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/prompt_image.dart';

class GalleryService {
  final SupabaseClient client = Supabase.instance.client;

  Future<List<PromptImage>> fetchImages({
    required int page,
    int limit = 20,
    String? categoryId,
    String? search,
  }) async {
    var query = client
        .from('images')
        .select('*, categories(name)')
        .eq('is_published', true);

    if (categoryId != null && categoryId.isNotEmpty) {
      query = query.eq('category_id', categoryId);
    }
    if (search != null && search.trim().isNotEmpty) {
      query = query.ilike('prompt', '%${search.trim()}%');
    }

    final rows = await query
        .order('created_at', ascending: false)
        .range(page * limit, page * limit + limit - 1);

    return rows.map<PromptImage>((e) => PromptImage.fromMap(e)).toList();
  }

  Future<void> addView(String id) async {
    await client.rpc('increment_image_view', params: {'image_uuid': id});
  }

  Future<List<Map<String, dynamic>>> categories() async {
    return await client
        .from('categories')
        .select('id,name,icon,parent_id')
        .eq('is_active', true)
        .order('sort_order');
  }

  Future<List<Map<String, dynamic>>> ads() async {
    return await client
        .from('advertisements')
        .select()
        .eq('is_active', true)
        .eq('position', 'prompt_detail')
        .order('priority', ascending: false);
  }
}
