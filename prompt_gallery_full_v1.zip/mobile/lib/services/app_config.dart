import 'package:supabase_flutter/supabase_flutter.dart';

class AppConfig {
  final String appName;
  final int totalImages;

  const AppConfig({required this.appName, required this.totalImages});

  static Future<AppConfig> load() async {
    try {
      final client = Supabase.instance.client;
      final settings = await client
          .from('app_settings')
          .select('key,value')
          .inFilter('key', ['app_name']);

      String name = 'Prompt Gallery';
      for (final row in settings) {
        if (row['key'] == 'app_name') name = row['value'] as String;
      }

      final countRow = await client
          .from('images')
          .select('id')
          .eq('is_published', true)
          .count(CountOption.exact);

      return AppConfig(appName: name, totalImages: countRow.count);
    } catch (_) {
      return const AppConfig(appName: 'Prompt Gallery', totalImages: 0);
    }
  }
}
