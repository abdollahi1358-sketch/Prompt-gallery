import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'services/app_config.dart';
import 'screens/home_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Put these in --dart-define for production.
  const url = String.fromEnvironment('SUPABASE_URL');
  const anonKey = String.fromEnvironment('SUPABASE_ANON_KEY');

  if (url.isNotEmpty && anonKey.isNotEmpty) {
    await Supabase.initialize(url: url, anonKey: anonKey);
  }

  final config = await AppConfig.load();

  runApp(PromptGalleryApp(config: config));
}

class PromptGalleryApp extends StatelessWidget {
  final AppConfig config;
  const PromptGalleryApp({super.key, required this.config});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: config.appName,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFDDF0C7),
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFFB6D800)),
      ),
      home: HomeScreen(config: config),
    );
  }
}
