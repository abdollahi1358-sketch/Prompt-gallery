# ساخت APK بدون کامپیوتر

این پروژه برای Flutter آماده شده و می‌توان آن را روی سرویس CI/CD ابری Build کرد.

## مسیر پیشنهادی
1. پروژه را در یک Git repository قرار بده.
2. Repository را به یک سرویس Flutter CI/CD مثل Codemagic متصل کن.
3. Android build را روی `release` تنظیم کن.
4. برای اتصال Backend این دو متغیر را در محیط Build قرار بده:
   - SUPABASE_URL
   - SUPABASE_ANON_KEY
5. خروجی APK را از داشبورد سرویس دریافت کن.

## نکته
برای انتشار در Google Play بهتر است AAB تولید شود؛ برای نصب مستقیم روی گوشی APK مناسب است.

## Backend
فایل `supabase/schema.sql` را در SQL Editor پروژه Supabase اجرا کن.
سپس تصاویر را در Storage قرار بده و URL آن‌ها را در جدول `images` ثبت کن.
