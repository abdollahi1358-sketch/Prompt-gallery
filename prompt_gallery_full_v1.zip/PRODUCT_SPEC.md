# Product Specification

## Mobile
1. Home: app name + total image count
2. Category chips
3. Search
4. Two-column infinite feed
5. White thick rounded image frames inspired by supplied reference
6. View count on image
7. Detail page
8. Full prompt
9. Copy prompt
10. Local Save without account
11. Open ChatGPT / Gemini
12. Admin-selected banner on detail page

## Admin
1. Dashboard
2. Images + prompts
3. Categories + subcategories
4. Advertisements
5. App name setting
6. Analytics

## Account policy
No user registration, no login, no user profile in MVP.
Saved items are device-local.
