'use client';
import {useState} from 'react';

export default function Settings() {
  const [name,setName] = useState('Prompt Gallery');
  return <main style={{padding:32}}>
    <h1>App Settings</h1>
    <label>App Name</label>
    <div><input value={name} onChange={e=>setName(e.target.value)}
      style={{padding:12,width:320,marginTop:8}} /></div>
    <button style={{marginTop:16,padding:'10px 18px'}}
      onClick={()=>alert('در نسخه متصل، این مقدار در app_settings ذخیره می‌شود.')}>
      Save
    </button>
  </main>
}
