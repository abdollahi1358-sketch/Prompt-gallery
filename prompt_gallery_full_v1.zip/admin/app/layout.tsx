import React from 'react';

export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="en"><body style={{fontFamily:'Arial',margin:0,background:'#f4f6ee'}}>{children}</body></html>
}
