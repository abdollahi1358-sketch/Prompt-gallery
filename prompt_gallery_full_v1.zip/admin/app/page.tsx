export default function Dashboard() {
  return (
    <main style={{padding:32}}>
      <h1>Prompt Gallery — Admin</h1>
      <p>مدیریت نام اپ، تصاویر، دسته‌بندی‌ها، پرامپت‌ها و تبلیغات.</p>
      <div style={{display:'grid',gridTemplateColumns:'repeat(2,minmax(220px,1fr))',gap:16}}>
        {[
          ['Images','مدیریت تصاویر و Promptها'],
          ['Categories','دسته‌بندی و زیر‌دسته'],
          ['Advertisements','بنر و تبلیغات'],
          ['Settings','نام اپلیکیشن و تنظیمات عمومی']
        ].map(([title,desc]) => (
          <section key={title} style={{background:'#fff',padding:24,borderRadius:20}}>
            <h2>{title}</h2><p>{desc}</p>
          </section>
        ))}
      </div>
    </main>
  );
}
