create extension if not exists pgcrypto;

create table if not exists app_settings (
  key text primary key,
  value text not null,
  updated_at timestamptz not null default now()
);

insert into app_settings(key,value)
values ('app_name','Prompt Gallery')
on conflict (key) do nothing;

create table if not exists categories (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text unique not null,
  icon text default '•',
  parent_id uuid references categories(id) on delete set null,
  sort_order int default 0,
  is_active boolean default true,
  created_at timestamptz default now()
);

create table if not exists images (
  id uuid primary key default gen_random_uuid(),
  image_url text not null,
  thumbnail_url text,
  title text,
  prompt text not null,
  category_id uuid references categories(id) on delete set null,
  ai_model text,
  views bigint not null default 0,
  is_published boolean not null default true,
  created_at timestamptz default now()
);

create index if not exists images_created_idx on images(created_at desc);
create index if not exists images_category_idx on images(category_id);

create table if not exists advertisements (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  image_url text not null,
  target_url text,
  position text not null default 'prompt_detail',
  start_at timestamptz,
  end_at timestamptz,
  priority int default 0,
  is_active boolean default true,
  created_at timestamptz default now()
);

create or replace function increment_image_view(image_uuid uuid)
returns void language sql security definer as $$
  update images set views = views + 1 where id = image_uuid;
$$;

insert into categories(name,slug,icon,sort_order) values
('Creatives','creatives','🎨',1),
('Cinematic','cinematic','🎬',2),
('Portrait','portrait','👤',3),
('Couple','couple','💑',4),
('Fashion','fashion','👗',5),
('Wedding','wedding','💍',6),
('Photography','photography','📸',7),
('Fantasy','fantasy','🧙',8),
('Product','product','🛍️',9),
('Poster','poster','🖼️',10)
on conflict(slug) do nothing;

-- Public read access for published gallery content.
alter table app_settings enable row level security;
alter table categories enable row level security;
alter table images enable row level security;
alter table advertisements enable row level security;

create policy "public read app settings" on app_settings for select using (true);
create policy "public read active categories" on categories for select using (is_active = true);
create policy "public read published images" on images for select using (is_published = true);
create policy "public read active ads" on advertisements for select using (
  is_active = true
  and (start_at is null or start_at <= now())
  and (end_at is null or end_at >= now())
);

-- IMPORTANT: Admin writes should be performed only from the protected admin
-- environment using Supabase service-role/server-side credentials.
